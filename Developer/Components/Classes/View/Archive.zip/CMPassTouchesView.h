//
//  CMPassTouchesView.h
//  Composition
//
//  Created by Describe Administrator on 20/01/14.
//  Copyright (c) 2014 Describe Administrator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMPassTouchesView : UIView

@property (nonatomic, assign) BOOL dontPassTouch;

@end
